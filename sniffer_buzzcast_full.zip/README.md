BuzzCast Sniffer - Ready-to-build Android Studio project (Kotlin)
---------------------------------------------------------------
This project provides a VPN-based packet sniffer that filters traffic for:
 - api.facecast.xyz
 - shortconn.im.qcloud.com
 - livepullsm.facecast.live
 - txlivecdn.com

How to build:
 1. Copy this folder to your PC with Android Studio (recommended) or try building in Termux (advanced).
 2. Open the project in Android Studio and let Gradle sync.
 3. Build -> Build APK(s).

Notes:
 - This project requires the user to accept the local VPN permission.
 - It reads raw IP packets from the tun interface and uses a simple string heuristic to find HTTP/1 traffic.
 - For HTTPS inspection you still need to install a MITM CA and/or use Frida to bypass pinning.
