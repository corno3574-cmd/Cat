plugins {
    kotlin("android") version "1.8.0" apply false
    id("com.android.application") version "7.4.0" apply false
}
