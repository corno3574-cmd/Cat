rootProject.name = "sniffer_buzzcast_full"
include(":app")
