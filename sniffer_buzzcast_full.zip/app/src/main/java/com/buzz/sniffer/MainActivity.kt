package com.buzz.sniffer

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.ViewGroup
import android.view.View
import android.widget.TextView
import android.widget.Toast
import android.os.Environment
import java.io.File

class MainActivity : Activity() {
    lateinit var rv: RecyclerView
    lateinit var adapter: LogAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val btn = Button(this)
        btn.text = "Start Sniffer (VPN)"
        layout.addView(btn, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val btnExport = Button(this)
        btnExport.text = "Export Logs"
        layout.addView(btnExport, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = LogAdapter()
        rv.adapter = adapter
        layout.addView(rv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        setContentView(layout)

        btn.setOnClickListener {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                startActivityForResult(intent, 1)
            } else {
                startService(Intent(this, VpnSnifferService::class.java))
                Toast.makeText(this, "Sniffer started", Toast.LENGTH_SHORT).show()
            }
        }
        btnExport.setOnClickListener {
            exportLogs()
        }
    }

    fun exportLogs() {
        val dir = File(getExternalFilesDir(null), "buzz_logs")
        if (!dir.exists()) dir.mkdirs()
        val out = File(dir, "logs.txt")
        out.writeText(adapter.getAll().joinToString("\n"))
        Toast.makeText(this, "Saved to: \${out.absolutePath}", Toast.LENGTH_LONG).show()
    }

    // Called by service via broadcast (simple approach)
    fun onNewLog(line: String) {
        runOnUiThread {
            adapter.add(line)
        }
    }
}

class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {
    val list = ArrayList<String>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context)
        tv.setPadding(8,8,8,8)
        return VH(tv)
    }
    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.tv.text = list[position]
    }
    override fun getItemCount(): Int = list.size
    fun add(s: String) { list.add(0, s); notifyDataSetChanged() }
    fun getAll(): List<String> = list
    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)
}
