package com.buzz.sniffer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.concurrent.thread
import java.nio.ByteBuffer
import java.net.InetAddress
import java.nio.charset.Charset
import android.content.Context
import android.content.IntentFilter
import android.util.Log

class VpnSnifferService : VpnService(), Runnable {

    private var tun: ParcelFileDescriptor? = null
    private val TAG = "VpnSnifferService"
    private val OUT_BUFFER = ByteArray(20000)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val builder = Builder()
        builder.addAddress("10.0.0.2", 32)
        builder.addRoute("0.0.0.0", 0)
        tun = builder.setSession("BuzzCastSniffer").establish()

        createNotification()
        Thread(this).start()
        return Service.START_STICKY
    }

    private fun createNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = "sniffer_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val c = NotificationChannel(ch, "Sniffer", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(c)
        }
        val n = Notification.Builder(this, ch)
            .setContentTitle("BuzzCast Sniffer")
            .setContentText("VPN sniffer is running")
            .build()
        startForeground(1337, n)
    }

    override fun run() {
        try {
            val fd = tun!!.fileDescriptor
            val fis = FileInputStream(fd)
            while (true) {
                val len = fis.read(OUT_BUFFER)
                if (len > 0) {
                    // Simple heuristic: convert to string and search for targets
                    val s = String(OUT_BUFFER, 0, len, Charset.forName("ISO-8859-1"))
                    if (s.contains("api.facecast.xyz") || s.contains("shortconn.im.qcloud.com") || s.contains("livepullsm.facecast.live") || s.contains("txlivecdn.com")) {
                        Log.i(TAG, "Captured: " + s.substring(0, Math.min(1000, s.length)))
                        // broadcast to activity (simple)
                        val b = Intent("com.buzz.sniffer.NEW_LOG")
                        b.putExtra("line", s.substring(0, Math.min(2000, s.length)))
                        sendBroadcast(b)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "error", e)
        }
    }

    override fun onDestroy() {
        try { tun?.close() } catch (e: Exception) {}
        super.onDestroy()
    }
}
